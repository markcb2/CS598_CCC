package com.usbank.ent.streaming.srvc.complexeventprocessing

import org.apache.kafka.clients.producer.{KafkaProducer,ProducerRecord}
import org.apache.log4j._
import org.apache.log4j.{Level, Logger}  

class KafkaMessagePublisher(brokerList: String, keySerializer: String, valueSerializer: String, acks: String, securityProtocolConfig: String) {
  val logger = Logger.getLogger(getClass().getName)
  val producer = new KafkaProducer[String, String](producerconfiguration)
  private def producerconfiguration = {
   //Producer properties 
   val props = new java.util.Properties
    props.put("bootstrap.servers", brokerList)
     logger.info("bootstrap.servers: " + brokerList)
    props.put("key.serializer", keySerializer)
     logger.info("key.serializer: " + keySerializer)
    props.put("value.serializer",valueSerializer)
     logger.info("value.serializer: " + valueSerializer)
    props.put("acks", "all")
     logger.info("Acknowledgement: " + acks)
    props.put("security.protocol", securityProtocolConfig)
     logger.info("security.protocol: "+ securityProtocolConfig)
    props
  } 
  def send(topic: String, key: String, value: String) {
    producer.send(new ProducerRecord(topic, key, value))
  }
}