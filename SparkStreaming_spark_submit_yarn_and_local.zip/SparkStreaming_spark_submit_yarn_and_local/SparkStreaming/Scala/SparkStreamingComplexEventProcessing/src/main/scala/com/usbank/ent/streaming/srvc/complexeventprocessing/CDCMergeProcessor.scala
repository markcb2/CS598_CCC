package com.usbank.ent.streaming.srvc.complexeventprocessing

import com.fasterxml.jackson.databind.{Module, ObjectMapper}
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import scala.io.Source
import java.io.StringWriter
import org.apache.log4j._
import org.apache.log4j.{Level, Logger}  

object CDCMergeProcessor  {
  
  case class Meta_data(
  var name: String,
  var value: String,
  var `type`: String
)

  case class Columns(
  var name: String,
  var value: String,
  var isPresent: Boolean,
  var beforeImage: String,
  var isPresentBeforeImage: Boolean
)

  case class Container(
  var correlation_id: String,
  var meta_data: List[Meta_data],
  var columns: List[Columns]
)
 
val logger = Logger.getLogger(getClass().getName)

def updateColumns (inColumnsCurrent: Columns, inColumnsNew: Columns) : Columns = {
     val outColumns: Columns = inColumnsNew
     if (inColumnsNew.name == "TBD") {
       outColumns.value = "TBD"
     }
     logger.debug(s"END of CDCMergeProcessor:updateColumns ######################################## outColumns : $outColumns")
     outColumns
   }

/*
   def updateEventType (inMetaData: Meta_data) : Meta_data = {
     val outMetaData: Meta_data = inMetaData
     if (inMetaData.name == "INFA_OP_TYPE") {
       outMetaData.value = "PROCESSED_EVENT"
     }
     outMetaData
   }
*/
   
def mergeCDCEvents (container1 : Container, container2: Container, targetContainer: Container) : Container = {
       val outContainer : Container = targetContainer
       if (container1.meta_data(2).value == "UPDATE_EVENT") {
         //outContainer.meta_data = container2.meta_data
         //outContainer.columns = container2.columns
         outContainer.correlation_id = container1.correlation_id
         outContainer.meta_data(8).value = container1.meta_data(8).value
         
         for ( a <- 0 until container1.columns.length ) {
           if (container1.columns(a).isPresentBeforeImage) {
             outContainer.columns(a).isPresentBeforeImage = container1.columns(a).isPresentBeforeImage
             outContainer.columns(a).beforeImage = container1.columns(a).beforeImage 
           }
         }
         
       } else if (container2.meta_data(2).value == "UPDATE_EVENT") {
         //outMetaData = container2.meta_data.map(updateEventType)
         //outColumms = container2.columns.map(updateColumns)
         outContainer.correlation_id = container2.correlation_id
         outContainer.meta_data(8).value = container2.meta_data(8).value
         for ( b <- 0 until container2.columns.length ) {
           if (container2.columns(b).isPresentBeforeImage) {
             outContainer.columns(b).isPresentBeforeImage = container2.columns(b).isPresentBeforeImage
             outContainer.columns(b).beforeImage = container2.columns(b).beforeImage 
           }
         }
       }
       logger.debug(s"END of CDCMergeProcessor:mergeCDCEvents ######################################## outContainer : $outContainer")
       outContainer  
}

def updateEventType (value1Json: String, value2Json: String) : String = {
      var valueOutJson: String = null
       if (value1Json.contains("INSERT_EVENT")) {
         valueOutJson = value1Json.toString().replace("INSERT_EVENT", "PROCESSED_EVENT")
       } else if (value2Json.contains("INSERT_EVENT")) {
         valueOutJson = value2Json.toString().replace("INSERT_EVENT", "PROCESSED_EVENT")
       }
       logger.debug(s"END of CDCMergeProcessor:updateEventType ######################################## valueOutJson : $valueOutJson")
       valueOutJson  
}
   
def CDCMergeProcessor(value1: String, value2: String):(String) = { 
    val value1Json = value1.mkString
    val value2Json = value2.mkString
    logger.info(s"Start of CDC Merge: ######################################## Event 1 : $value1Json")
    logger.info(s"Start of CDC Merge: ######################################## Event 2 : $value2Json")
    
    val mapper = new ObjectMapper()
    mapper.registerModule(DefaultScalaModule)
    var outContainer: Container = null;
    
    try{
       var valueOutJson = value1Json
       var container1 = mapper.readValue(value1Json, classOf[Container])
       var container2 = mapper.readValue(value2Json, classOf[Container])
       
       valueOutJson = updateEventType (value1Json, value2Json)

       outContainer = mapper.readValue(valueOutJson, classOf[Container])
       outContainer = mergeCDCEvents(container1, container2, outContainer)
       logger.info(s"END of CDC Merge ######################################## outJson : $outContainer")

       val out = new StringWriter
       mapper.writeValue(out, outContainer)
       val outJsonString = out.toString() // .replace("INSERT_EVENT", "PROCESSED_EVENT")
       logger.info(outJsonString)
       //println(outJsonString)
       //println(s"END of CDC Merge $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ : $outJsonString")
       outJsonString
    }
    catch{
      case e: Exception => e.printStackTrace()
      throw new Exception("CDCMergeProcessor:Exception:" + e.printStackTrace().toString())
    } 
  }
}

