package com.usbank.ent.streaming.srvc.complexeventprocessing.phonechange

import org.apache.spark._
import org.apache.kafka.clients.producer
import org.apache.kafka.clients.consumer
import org.apache.kafka.clients.consumer.ConsumerConfig
import org.apache.spark.streaming._
import org.apache.spark.streaming.kafka010._
import org.apache.spark.SparkConf
import org.apache.log4j._
import org.apache.log4j.{Level, Logger}  
import java.io.File
import java.util.{Properties, UUID}
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.kafka.common.serialization.StringDeserializer
import org.apache.kafka.common.serialization.StringSerializer
import java.io.StringWriter
import com.usbank.ent.streaming.srvc.complexeventprocessing.KafkaMessagePublisher
import com.usbank.ent.streaming.srvc.complexeventprocessing.CDCMergeProcessor._
import java.util.Properties
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.spark.streaming.Milliseconds
import org.apache.spark.streaming.kafka010.DefaultPerPartitionConfig
import com.fasterxml.jackson.databind.{Module, ObjectMapper}
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import scala.io.Source
import java.io.StringWriter


object KafkaProducerConsumer {
  
//Setup logging level
val logger = Logger.getLogger(getClass().getName)

//Initialize config properties
var brokers =""
var groupId =""
var inputTopics = ""
var outputTopics = ""
var securityProtocolConfig =""
var windowSizeInSeconds = ""
var slideSizeInSeconds = ""
var numOfTasks = ""
var checkPointDir = ""
var keyDeserializer = ""
var valueDeserializer = ""
var keySerializer = ""
var valueSerializer = ""
var acks = ""
var msgKey = ""
var msgtosend =""
var checkpointDirectory =""
var insertEvent = ""
var updateEvent = ""
var processedEvent = ""
var operationType = ""
var noExpiry = ""
var capxActionUpdate = ""
var capxActionDelete = ""
var processedEventType = ""
var cleanedupEventType = ""
var deleteEvent = ""
var shouldRunInIDE=""
 
// Main function
 def main(args: Array[String]) {
   
    //Get filename
    var fileName = ""
    if (args.length != 1) {
      logger.error("Please specify configuration file name with the correct path ")
      System.exit(-1)
    } else {
      fileName = args(0)
      logger.info("configuration file path and file name: " + fileName)
    }
   
  //Get Properties info from config file  
  val config = AppConfig(fileName)
  //Set Kafka producer properties
  logger.debug("Set kafka producer properties succesfully")
     
  //Setup spark conf  
  logger.debug("Setting up Spark Conf")  
  var sparkConf = new SparkConf()
  
  if (shouldRunInIDE.equalsIgnoreCase("Y")){
    sparkConf.setMaster("local[*]")
    sparkConf.setAppName("KafkaProducerConsumer_Phone")
  }
  
  val ssc = new StreamingContext(sparkConf, Seconds(5))
  var broadcastVar = ssc.sparkContext.broadcast(config)

   
  //Split topics if there are multiple input and output topics separated by comma delimiter   
  val topicsInputSet = inputTopics.split(",").toSet
  val topicsOutputSet = outputTopics.split(",").toSet
  
  //Get Consumer properties
  val consumerProps = Map[String, Object]("bootstrap.servers" -> brokers,"key.deserializer" -> keyDeserializer,"value.deserializer" -> valueDeserializer,"group.id" -> groupId, "auto.offset.reset" -> "latest", "security.protocol" ->securityProtocolConfig)

  //Read Kafka topic
  logger.debug("Read messages from Kafka Stream")
  val messages = KafkaUtils.createDirectStream[String, String](ssc,PreferConsistent,Subscribe[String, String](topicsInputSet, consumerProps))
  logger.debug("Messages read successfully")  
     
  //Map Key value of the record.  Call CDC Merge processor custom function from reduce by key and window
  val processedmsg = messages.map(record=> (record.key,record.value)).reduceByKeyAndWindow(CDCMergeProcessor (_,_) , Seconds(windowSizeInSeconds.toInt), Seconds(slideSizeInSeconds.toInt),numOfTasks.toInt)
  logger.debug ("ReduceByKeyAndWindow function called successfully")
  
  var workerConfig = broadcastVar.value
  
  //Call get Event type function
  val finalOutput = processedmsg.map(outmessage =>setEventType(outmessage._1, outmessage._2, workerConfig) )
     
  //Send key value pair returned from the CDCMergeProcessor function to kafka stream
  logger.info("Before processing for each RDD of FinalStream: finalOutput:" + finalOutput + ":End of finalOutput")

  val finalStream = finalOutput
   finalStream.foreachRDD((rdd) => {
    rdd.foreachPartition((iter) => {
       
       logger.debug("KafkaProducerConfig Properties: " + workerConfig.getString("config.brokers") + " : " + workerConfig.getString("config.keySerializer") + " : " + workerConfig.getString("config.valueSerializer") + " : " + workerConfig.getString("config.acks") + " : " + workerConfig.getString("config.securityProtocolConfig"))
       val producer = new KafkaMessagePublisher(workerConfig.getString("config.brokers"), workerConfig.getString("config.keySerializer"), workerConfig.getString("config.valueSerializer"), workerConfig.getString("config.acks"), workerConfig.getString("config.securityProtocolConfig"))
       iter.foreach({ case(outmessage) =>
       logger.debug("Before broadcast: outmessage:key" + outmessage._1 + ": outmessage value:" + outmessage._2 + "End of outmessage")
       logger.debug("Sending to Kafka topic" + broadcastVar.value.getString("config.outputKafkaTopic") + " now! " )
 
       //Send to Kafka
       producer.send(broadcastVar.value.getString("config.outputKafkaTopic"), outmessage._1, outmessage._2)
       logger.info("Message sent to Kafka Topic")
    })
  }) 
})            

  //Set checkpoint directory
  ssc.checkpoint(checkPointDir)  
  
  //Start ssc
  logger.debug("Starting SSC")
  ssc.start()
  
  //Stop ssc
  logger.debug("Awaiting SSC Termination")
  ssc.awaitTermination()
  logger.debug("SSC Successfully terminated")
}

//Read config file and extract properties
def AppConfig (fileName: String): Config = {  
  val myConfigFile = new File(fileName)
  val fileConfig = ConfigFactory.parseFile(myConfigFile)
    brokers =fileConfig.getString("config.brokers")
     logger.info("Kafka Brokers: " + brokers)
    groupId =fileConfig.getString("config.groupId")
     logger.info("Consumer Group ID: " + groupId)
    inputTopics = fileConfig.getString("config.inputKafkaTopic")
     logger.info("Input Topic: " + inputTopics)
    outputTopics = fileConfig.getString("config.outputKafkaTopic")
     logger.info("Output Topic: " + outputTopics)
    securityProtocolConfig = fileConfig.getString("config.securityProtocolConfig")
      logger.info("Security Protocol Config: " + securityProtocolConfig)
    windowSizeInSeconds = fileConfig.getString("config.windowSizeInSeconds")
     logger.info("Window Size in Seconds: " + windowSizeInSeconds)
    slideSizeInSeconds = fileConfig.getString("config.slideSizeInSeconds")
     logger.info("Slide Size in Seconds: " + slideSizeInSeconds)
    numOfTasks = fileConfig.getString("config.numOfTasks")
     logger.info("Number of Tasks: " + numOfTasks)
    checkPointDir = fileConfig.getString("config.checkpointDirectory")
     logger.info("Check Point Directory: " + checkPointDir)
    keyDeserializer = fileConfig.getString("config.keyDeserializer")
     logger.info("Key Deserializer: " + keyDeserializer) 
    valueDeserializer = fileConfig.getString("config.valueDeserializer")
     logger.info("Value Deserializer: " + valueDeserializer) 
    keySerializer = fileConfig.getString("config.keySerializer")
     logger.info("Key Serializer: " + keySerializer) 
    valueSerializer = fileConfig.getString("config.valueSerializer")
     logger.info("Value Serializer: " + valueSerializer) 
    acks = fileConfig.getString("config.acks")
     logger.info("Acknowledgement: " + acks)  
    checkpointDirectory = fileConfig.getString("config.checkpointDirectory")
     logger.info("Checkpoint Directory:" +checkpointDirectory)
    insertEvent = fileConfig.getString("config.insertEvent")
     logger.info("Insert Event:" +insertEvent)
    updateEvent = fileConfig.getString("config.updateEvent")
     logger.info("Update Event:" +updateEvent)
    processedEvent = fileConfig.getString("config.processedEvent")
     logger.info("Processed Event:" +processedEvent)
    operationType = fileConfig.getString("config.operationType")
     logger.info("Operation Type:" +operationType)
    noExpiry = fileConfig.getString("config.noExpiry")
     logger.info("No Expiry:" +noExpiry)
    capxActionUpdate = fileConfig.getString("config.capxActionUpdate")
     logger.info("Capex Action Update:" +capxActionUpdate)
    capxActionDelete = fileConfig.getString("config.capxActionDelete")
     logger.info("Capex Action Delete:" +capxActionDelete)
    processedEventType = fileConfig.getString("config.processedEventType")
     logger.info("Processed Event Type:" +processedEventType)
    cleanedupEventType = fileConfig.getString("config.cleanedupEventType")
     logger.info("Cleaned up Event Type:" +cleanedupEventType)
    deleteEvent = fileConfig.getString("config.deleteEvent")
     logger.info("Delete Event:" +deleteEvent)
    shouldRunInIDE = fileConfig.getString("config.shouldRunInIDE")
     logger.info("Should Run In IDE Flag: " + shouldRunInIDE)
     fileConfig
 }

  case class Meta_data(
  var name: String,
  var value: String,
  var `type`: String
)

  case class Columns(
  var name: String,
  var value: String,
  var isPresent: Boolean,
  var beforeImage: String,
  var isPresentBeforeImage: Boolean
)

  case class Container(
  var correlation_id: String,
  var meta_data: List[Meta_data],
  var columns: List[Columns]
)
 

// Set Event type 
def setEventType (msgKey: String, msgToProcess: String, config: Config):(String,String)={
      val valueJson = msgToProcess.mkString
      val mapper = new ObjectMapper()
      mapper.registerModule(DefaultScalaModule)
      var container: Container = mapper.readValue(valueJson, classOf[Container])
    
      val sliceEventType = container.meta_data(2).value
      //val indexofEventwithNoExpiryDate = msgToProcess.indexOfSlice(config.getString("config.noExpiry"))
      val expiryDate = container.columns(29).value
      val insertEvent = config.getString("config.insertEvent")
      val updateEvent = config.getString("config.updateEvent")
      val deleteEvent = config.getString("config.deleteEvent")
      val capxActionUpdate = config.getString("config.capxActionUpdate")
      val capxActionDelete = config.getString("config.capxActionDelete")
      val processedEventType = config.getString("config.processedEventType")
      val cleanedupEventType = config.getString("config.cleanedupEventType")
      logger.info("Start of setEventType : " + msgKey + " : " + msgToProcess + " : cleanedupEventType = " + cleanedupEventType)

      if (insertEvent == sliceEventType || (updateEvent == sliceEventType && expiryDate == "0")) {
         msgtosend = msgToProcess
      } else if (updateEvent == sliceEventType && expiryDate != "0") {
         container.meta_data(2).value = deleteEvent
         container.meta_data(8).value = capxActionDelete
         val out = new StringWriter
         mapper.writeValue(out, container)
         msgtosend = out.toString()
      } else if (processedEventType == sliceEventType) {
         container.meta_data(2).value = cleanedupEventType
         val out = new StringWriter
         mapper.writeValue(out, container)
         msgtosend = out.toString()
      } else {
         msgtosend = msgToProcess
      }
      logger.info("Messages returned successfully from function setEventType : " + msgKey + " : " + msgtosend)
 
      return(msgKey, msgtosend)
    }
}