package com.usbank.edm.ent.stream.srvc.poc
import org.apache.spark._
import org.apache.spark.SparkContext._
import org.apache.spark.sql._
import org.apache.log4j._
import org.apache.spark.sql.functions._
import Utilities._
import java.io.File
import com.typesafe.config.ConfigFactory
import org.apache.log4j.{Level, Logger}  
import scala.collection.JavaConversions._
import org.apache.log4j.{Level, Logger}


object ComplexEventProcessing {
  
  val logger = Logger.getLogger(getClass().getName)
  
  def setupLogging() = { 
    logger.setLevel(Level.INFO)   
  }
  
  def main(args: Array[String]) {
    setupLogging()
    var fileName = ""

    if (args.length != 1) {
      logger.info("Fully Qualified Path and File Name <path>/<fileName> is missing from the command line for the configuration file. Please specify ")
      System.exit(-1)
    } else {
      fileName = args(0)
      logger.info("configuration file path and file name: " + fileName)
    }
    val myConfigFile = new File(fileName)
    val fileConfig = ConfigFactory.parseFile(myConfigFile)
    
    val kafkaHosts = fileConfig.getString("configs.kafkaHost")
    logger.info("Kafka Brokers: " + kafkaHosts)
    val inputKafkaTopic = fileConfig.getString("configs.inputKafkaTopic")
    logger.info("Input Kafka Topic: " + inputKafkaTopic)
    val outputKafkaTopic = fileConfig.getString("configs.outputKafkaTopic")
    logger.info("Output Kafka Topic: " + outputKafkaTopic)
    val checkpointDirectory = fileConfig.getString("configs.checkpointDirectory")
    logger.info("checkpointDirectory: " + checkpointDirectory)
    val kafkaConsumerGroupId = fileConfig.getString("configs.kafkaConsumerGroupId")
    logger.info("kafkaConsumerGroupId: " + kafkaConsumerGroupId)
    val sparkMasterLocation = fileConfig.getString("configs.sparkMasterLocation")
    logger.info("sparkMasterLocation: " + sparkMasterLocation)
    val appName = fileConfig.getString("configs.appName")
    logger.info("appName: " + appName)
    val windowSizeInSeconds = fileConfig.getInt("configs.windowSizeInSeconds")
    logger.info("windowSizeInSeconds: " + windowSizeInSeconds)
    val slideSizeInSeconds = fileConfig.getInt("configs.slideSizeInSeconds")
    logger.info("slideSizeInSeconds: " + slideSizeInSeconds)
    val sparkSQLWarehouseDirectory = fileConfig.getString("configs.sparkSQLWarehouseDirectory")
    
     val spark = SparkSession
        .builder
        .appName(appName)
        .master(sparkMasterLocation)
        .config("spark.sql.warehouse.dir", checkpointDirectory) // Necessary to work around a Windows bug in Spark 2.0.0; omit if you're not on Windows.
        .config("spark.sql.streaming.checkpointLocation", sparkSQLWarehouseDirectory)
        .getOrCreate()
    
        
    import spark.implicits._
        
     val input_df = spark
        .readStream
        .format("kafka")
        .option("kafka.bootstrap.servers", kafkaHosts)
        .option("subscribe", inputKafkaTopic)
        .option("startingOffsets","earliest")
        .load()
        
     logger.info("Read input row from Kafka: " + input_df.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)").as[(String, String)])  
     
     val output_df = input_df
        .selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")
        .writeStream
        .format("kafka")
        .option("kafka.bootstrap.servers", kafkaHosts)
        .option("topic", outputKafkaTopic)
        .start()
      
        output_df.awaitTermination()
  }
  
}