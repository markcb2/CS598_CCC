package com.usbank.edm.ent.stream.srvc.json
import com.fasterxml.jackson.databind.{Module, ObjectMapper}
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import scala.io.Source
import java.io.StringWriter

object jsonDeserializerAndSerializer {
  
  case class Meta_data(
   var name: String,
   var value: String,
   var `type`: String
)
case class Columns(
  var name: String,
  var value: String,
  var isPresent: Boolean,
  var beforeImage: String,
  var isPresentBeforeImage: Boolean
)
case class Container(
  var meta_data: List[Meta_data],
  var columns: List[Columns]
)

  def updateColumns(column: Columns): Columns = {
    
    var col = new Columns(name="foo", value="boo", isPresent = true, beforeImage = "Schmoo", isPresentBeforeImage = true)
    col
  }
  
  def printCol(column: Columns): Columns = {
    
    var stringBuf = new StringBuffer()
    stringBuf.append(column.name + " : ")
    stringBuf.append(column.value + " : ")
    stringBuf.append(column.isPresent + " : ")
    stringBuf.append(column.beforeImage + " : ")
    stringBuf.append(column.isPresentBeforeImage)
    println("column values: " + stringBuf.toString())
    var col = column
    column
  }
  
  def main(args: Array[String]) { 
    val whereami = System.getProperty("user.dir")
    println(whereami)
    val filename = "./src/main/resources/update_24373_02.json"
    val source = Source.fromFile(filename)
    val jsonAsString = source.getLines.mkString
    println(jsonAsString)
    source.close()
    val mapper = new ObjectMapper()
    mapper.registerModule(DefaultScalaModule)
    try{
     var container = mapper.readValue(jsonAsString, classOf[Container])
     var event_type = container.meta_data(1).value
     println("event type before updating: " + event_type)
     container.meta_data(1).value = "Phone Update"
     println("event type after updating: " + container.meta_data(1).value)
     var operation_type = container.meta_data(2).value
     println("operation_type before updating: " + operation_type)
     container.meta_data(2).value = "BALOO"
     container.columns.map(updateColumns).map(col => printCol(col))
     println("operation type after updating " + container.meta_data(2).value)
     val out = new StringWriter
     mapper.writeValue(out, container)
     val json_output = out.toString()
     println(json_output)
    }
    catch{
      case e: Exception => e.printStackTrace()
    }
    
  }
}