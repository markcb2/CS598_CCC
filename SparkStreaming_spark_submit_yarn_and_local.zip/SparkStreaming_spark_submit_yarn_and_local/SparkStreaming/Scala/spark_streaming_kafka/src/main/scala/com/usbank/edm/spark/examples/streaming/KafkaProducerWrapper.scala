package com.usbank.edm.spark.examples.streaming

import java.util.Properties
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord}
import org.apache.kafka.common.serialization.StringDeserializer

case class KafkaProducerWrapper(brokerList: String) {

 var props = new Properties();
 props.put("bootstrap.servers", brokerList);
 props.put("acks", "all");
 props.put("retries", new Integer(3));
 props.put("batch.size", new Integer(16384));
 props.put("linger.ms", new Integer(1));
 props.put("buffer.memory", new Integer(33554432));
 props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
 props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

 val producer = new KafkaProducer[String, String](props);
   
  def send(topic: String, key: String, value: String) {
    producer.send(new ProducerRecord[String, String](topic, key, value))
  }
}
object KafkaProducerWrapper {
  var brokerList = ""
  lazy val instance = new KafkaProducerWrapper(brokerList)
}
